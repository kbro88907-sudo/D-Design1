# بورتفوليو المصمم المحترف

موقع بورتفوليو لمصمم جرافيك (React + Vite + Tailwind + Firebase).

## التشغيل محليًا
```
npm install
npm run dev
```

## النشر على GitHub Pages
1. ارفع المشروع على GitHub (الفرع `main`).
2. من Settings ← Pages ← Source اختار **GitHub Actions**.
3. أي push على `main` هينشر الموقع تلقائيًا.
